p "p"
puts "puts"
print "print"
my_name = "Jessie"
print my_name
beginning_sentence = "My name is "
full_sentence = beginning_sentence + my_name
