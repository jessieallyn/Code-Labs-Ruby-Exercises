def say_hello_to(name)
  puts "Hello, #{name}!"
end

my_name = "Jessie"

say_hello_to(my_name)
