def names_of_my_pets(name_1, name_2, name_3)
  puts "I have 3 pets! Their names are #{name_1}, #{name_2}, and #{name_3}!"
end

name_1 = "Jaeger"
name_2 = "Ruger"
name_3 = "Stripes"

names_of_my_pets(name_1, name_2, name_3)